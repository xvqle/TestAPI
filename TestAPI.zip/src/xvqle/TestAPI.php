<?php

namespace xvqle;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\inventory\InventoryEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\PluginDescription;
use pocketmine\plugin\PluginLoader;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\plugin\PluginManager;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\plugin\PluginDisableEvent;
use xvqle\HCF\PlayerSendScoreBoardEvent;

use function strtolower;


class TestAPI extends PluginBase implements Listener
{
    public function onEnable()
    {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("TESTAPI ENABLED");
    }

    public function onJoin(PlayerJoinEvent $event)
    {
        $player = $event->getPlayer();
        $player->sendMessage("HOWDY!");
    }

    public function onHCFDeath(PlayerDeathEvent $event){
        $player = $event->getPlayer();
        //$event->setDeathMessage($prefix .  $player->getName(). "was killed by" . $entity->getName() . "using" . $entity->getPlayer()->getInventory()->getItemInHand()->getName();


    }
   public function onDisable(){
        $this->onDisable();
        $this->getLogger()->info("DISABLED");

   }
   
   
   public function onPlayerSendScoreBoardEvent(){
       $packet = new SetDisplayObjectivePacket();
		$packet->displaySlot = $displaySlot;
		$packet->objectiveName = "objective";
		$packet->displayName = $displayName;
		$packet->criteriaName = "dummy";
		$packet->sortOrder = $sortOrder;
		$player->sendDataPacket($packet);
		//self::$scoreboard[$player->getName()] = $player->getName();
		
		
	//todo add a custom scoreboard
	}

}


